function Memories() {
  return <h2>Photos and Memories</h2>;
}
export default Memories;
