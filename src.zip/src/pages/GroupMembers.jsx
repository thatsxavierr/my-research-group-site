function GroupMembers() {
return (
    <div className="page-content">
      <h1>Group Members</h1>
      <p>Meet Our Team.</p>
    </div>
  );
}
export default GroupMembers;
