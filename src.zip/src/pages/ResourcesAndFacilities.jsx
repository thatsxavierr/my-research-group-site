function ResourcesAndFacilities() {
  return (
    <div className="page-content">
      <h1>Resources and Lab Facilities</h1>
      <p>This section highlights the cutting-edge resources and lab infrastructure available to the Oxide Epitaxy Group.</p>
    </div>
  );
}

export default ResourcesAndFacilities;
