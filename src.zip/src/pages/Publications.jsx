function Publications() {
  return <h2>Our Publications</h2>;
}
export default Publications;
